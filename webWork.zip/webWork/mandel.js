﻿var numberOfWorkers = 8;
var workers = [];

window.onload = init;

function init() {
    //得到画布的上下文,将画布大小调整为浏览器的大小，还会处理另外一些图形方面的细节问题.
    setupGraphics();//位于mandellib.js

    for (var i = 0; i < numberOfWorkers; i++) {
        //创建工作线程
        var worker = new Worker("worker.js");//1

        //线程的消息处理程序(线程回传的)
        worker.onmessage = function (event) {
            processWork(event.target, event.data);//6
        }
        
        //向工作线程增加一个idle属性,标识是否在工作
        worker.idle = true;

        workers.push(worker);

    }

    startWorkers();

    canvas.onclick = function (event) {
        handleClick(event.clientX, event.clientY);
    }

    window.onresize = function () {
        resizeToWindow();
    }
}

var nextRow = 0;//跟踪处理图像过程中处理到哪一行
var generation = 0;//放大一次将会重新计算新的图像,generation变量将跟踪计算了多少次.

//启动工作线程,如果用户放大图像,也会重启工作线程.
function startWorkers() {
    generation++;
    nextRow = 0;

    for (var i = 0; i < workers.length; i++) {
        var worker = workers[i];
        if (worker.idle) {
            //如果空闲,就为这个工作线程分配一个任务
            var task = createTask(nextRow);//将工作线程计算一行像素所需的数据全部打包为一个对象.位于mandellib.js2

            worker.idle = false;//已分配任务
            worker.postMessage(task);//告诉工作线程开始工作，当接受到消息时就开始处理这个任务。3

            nextRow++;//处理下一行
        }
    }
}

//将计算结果传递到drawRow在画布上绘制这些像素.6
function processWork(worker, workerResults) {
    if (workerResults.generation == generation) {
        drawRow(workerResults);//位于mandellib.js
    }
    
    //工作线程完成后为它重新分配一个任务7
    reassignWorker(worker);
}

function reassignWorker(worker) {
    var row = nextRow++;

    if (row >= canvas.height) {
        worker.idle = true;
    }
    else {
        var task = createTask(row);
        worker.idle = false;
        worker.postMessage(task);
    }
}

function handleClick(x, y) {
    var width = r_max - r_min;
    var height = i_min - i_max;
    var click_r = r_min + width * x / canvas.width;
    var click_i = i_max + height * y / canvas.height;

    var zoom = 8;

    r_min = click_r - width / zoom;
    r_max = click_r + width / zoom;
    i_max = click_i - height / zoom;
    i_min = click_i + height / zoom;

    startWorkers();
}

function resizeToWindow() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    var width = ((i_max - i_min) * canvas.width / canvas.height);
    var r_mid = (r_max + r_min) / 2;
    r_min = r_mid - width / 2;
    r_max = r_mid + width / 2;
    rowData = ctx.createImageData(canvas.width, 1);

    startWorkers();
}