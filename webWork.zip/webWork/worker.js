﻿importScripts("workerlib.js");

onmessage = function (task) {
    var workerResult = computeRow(task.data);//4位于workerlib.js
    postMessage(workerResult);//5
}